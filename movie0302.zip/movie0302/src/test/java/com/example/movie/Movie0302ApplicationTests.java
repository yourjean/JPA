package com.example.movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Movie0302ApplicationTests {

    @Test
    void contextLoads() {
    }

}
