package com.example.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Movie0302Application {

    public static void main(String[] args) {
        SpringApplication.run(Movie0302Application.class, args);
    }

}
