package com.study.springboot.controller;

import com.study.springboot.entity.Notice;
import com.study.springboot.repository.NoticeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.annotation.PostConstruct;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class MyController {

    private final NoticeRepository noticeRepository;
    //@PostConstruct
    public void init(){
        Notice notice = Notice.builder().seq(20000L).title("제목2").content("내용2").build();
        //noticeRepository.insertNotice(notice);
        //noticeRepository.flush();
        noticeRepository.saveAndFlush(notice);
    }

    //기본페이지 컨트롤러
    @GetMapping("/")
    public String root(){

        return "view/index";
    }

    //list.html나오도록
    @GetMapping("/page2")
    public String listAction(Model model, @PageableDefault(page = 0, size = 10) Pageable pageable) {
        List<Notice> list = noticeRepository.findAll();
        final int start = (int) pageable.getOffset();
        final int end = Math.min((start + pageable.getPageSize()), list.size());
        final Page<Notice> page = new PageImpl<>(list.subList(start, end), pageable, list.size());

        model.addAttribute("list", page);
        return "view/list";
    }

}
