package com.study.springboot.repository;

import com.study.springboot.entity.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;

public interface NoticeRepository extends JpaRepository<Notice,Long> {

    @Modifying
    @Transactional
    @Query(value = "insert into notice (seq, title, content) values(:#{#notice.seq}, :#{#notice.title}, :#{#notice.content})", nativeQuery = true)
    public void insertNotice(@Param("notice") Notice notice);

    //notice에서 seq가장 큰 값 가져오기
    @Query(value = "select max(seq) from notice", nativeQuery = true)
    public Long selectMaxSeq();


}
