package com.study.springboot.repository;

import com.study.springboot.entity.Notice;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.transaction.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class NoticeRepositoryTest {

    @Autowired
    NoticeRepository noticeRepository;
    @Test
    @Disabled
    public void testIns(){
        Notice notice = Notice.builder().seq(10000L).title("제목1").content("내용1").build();
        //noticeRepository.insertNotice(notice);
        //noticeRepository.flush();
        noticeRepository.saveAndFlush(notice);
    }

    //제일 큰 seq 다음에 seq insert 하기
    @Test
    @Disabled
    public void testIns2(){
        Long seq=noticeRepository.selectMaxSeq();
        Notice notice = Notice.builder().seq(seq+10000L).title("제목1").content("내용1").build();
        noticeRepository.insertNotice(notice);
        //noticeRepository.flush();
        //noticeRepository.saveAndFlush(notice);
    }
}