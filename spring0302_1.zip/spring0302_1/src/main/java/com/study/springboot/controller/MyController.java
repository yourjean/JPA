package com.study.springboot.controller;

import com.study.springboot.entity.Movie;
import com.study.springboot.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.DiscriminatorColumn;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class MyController {

    private final MovieRepository movieRepository;

    public void init() {
        Movie movie = Movie.builder().title("제목11").content("내용11").idx(11).build();
        //movieRepository.insertMovie(movie);
        //movieRepository.flush();
        movieRepository.saveAndFlush(movie);
    }
        @GetMapping("/")
        public String root(){
            return "view/index";
    }

    //@GetMapping("/page2")
    //public String listAction(Model model, @PageableDefault(page = 0, size = 10) Pageable pageable) {
        //List<Movie> list = movieRepository.findAll();
        //final int start = (int) pageable.getOffset();
        //final int end = Math.min((start + pageable.getPageSize()), list.size());
        //final Page<Movie> page = new PageImpl<>(list.subList(start, end), pageable, list.size());

        //model.addAttribute("list", page);
        //return "view/list";
    //}

    //@GetMapping("/list")
    //public String selectAll(Model model) {
        //List<Movie> list = movieRepository.selectAll();
        //model.addAttribute("list",list);
        //return "view/list";
    //}



}
