package com.study.springboot.repository;

import com.study.springboot.entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface MovieRepository extends JpaRepository<Movie,Integer> {

    @Modifying
    @Transactional
    @Query(value = "insert into movie (title,content,idx) values(:#{#movie.title},:#{#movie.content},:#{#movie.idx})",nativeQuery = true)
    public void insertMovie(@Param("movie") Movie movie);

    @Query(value = "select did,title,content,idx from Movie")
    public List<Movie> selectAll();


}
