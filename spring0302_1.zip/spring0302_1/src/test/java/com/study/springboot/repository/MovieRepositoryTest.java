package com.study.springboot.repository;

import com.study.springboot.entity.Movie;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class MovieRepositoryTest {

    @Autowired
    MovieRepository movieRepository;

    @Test
    @Disabled
    public void testIns(){
        Movie movie = Movie.builder().title("제목11").content("내용11").idx(11).build();
        //noticeRepository.insertNotice(notice);
        //noticeRepository.flush();
        movieRepository.insertMovie(movie);
    }

    @Test
    public void testSel(){
        List<Movie> mlist=movieRepository.selectAll();
    }


}