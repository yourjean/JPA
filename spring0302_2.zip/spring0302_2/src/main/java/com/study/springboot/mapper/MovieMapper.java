package com.study.springboot.mapper;

import com.study.springboot.entity.Movie;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MovieMapper {

    @Select("select * from Movie")
    public List<Movie> selectAll();

    @Insert("insert into movie(title,content,idx) values (#{title}, #{content}, #{idx})")
    public void insertMovie(Movie movie);

    @Delete("delete from movie where did=#{did}")
    public int deleteMovie(int did);

    @Update("UPDATE Movie SET title=#{title}, content=#{content}, idx=#{idx} WHERE did=#{did}")
    public void updateMovie(Movie movie);

    @Select("Select * from movie where did=#{did}")
    public List<Movie> selectOne(int did);

    @Select("Select * from movie where idx=0")
    public List<Movie> selectAction();

    @Select("select * from movie where idx=1")
    public List<Movie> selectDrama();

    @Select("Select * from movie where idx=2")
    public List<Movie> selectFamily();

    @Select("select * from movie where idx=3")
    public List<Movie> selectComic();

    @Select("Select * from movie where idx=4")
    public List<Movie> selectHorror();

    @Select("Select * from movie where idx=5")
    public List<Movie> selectScience();
}
