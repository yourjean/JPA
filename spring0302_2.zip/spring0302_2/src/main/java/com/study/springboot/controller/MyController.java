package com.study.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.study.springboot.entity.Movie;
import com.study.springboot.mapper.MovieMapper;

@Controller
public class MyController {

	@Autowired
	private MovieMapper mMapper;

	@GetMapping("/")
	public String root() {
		return "view/index";
	}

	@GetMapping("/list")
	public String ListMapper(Model model) {
		List<Movie> mlist = mMapper.selectAll();
		model.addAttribute("mlist", mlist);
		return "view/list";
	}

	@GetMapping("/insert")
	public String insertPage() {
		return "view/insert";
	}

	@PostMapping("/insert.do")
	public String insertMovie(Movie movie) {
		mMapper.insertMovie(movie);
		return "redirect:list";
	}

	@GetMapping("/delete.do")
	public String deleteMovie(int did) {
		mMapper.deleteMovie(did);
		return "redirect:list";
	}
	
	@GetMapping("/update")
	public String updatePage(Model model, int did) {
		List<Movie> mlist=mMapper.selectOne(did);
		model.addAttribute("mlist", mlist);
		return "view/update";
	}
	
	@PostMapping("/update.do")
	public String updateMovie(Movie movie) {
		mMapper.updateMovie(movie);
		return "redirect:list";
	}
	
	@GetMapping("/action")
	public String selectAction(Model model) {
		List<Movie> mlist = mMapper.selectAction();
		model.addAttribute("mlist", mlist);
		return "view/action";
	}
	
	@GetMapping("/drama")
	public String selectDrama(Model model) {
		List<Movie> mlist = mMapper.selectDrama();
		model.addAttribute("mlist",mlist);
		return "view/drama";
	}
	
	@GetMapping("/family")
	public String selectFamily(Model model) {
		List<Movie> mlist = mMapper.selectFamily();
		model.addAttribute("mlist", mlist);
		return "view/family";
	}
	
	@GetMapping("/comic")
	public String selectComic(Model model) {
		List<Movie> mlist = mMapper.selectComic();
		model.addAttribute("mlist",mlist);
		return "view/comic";
	}
	
	@GetMapping("/horror")
	public String selectHorror(Model model) {
		List<Movie> mlist = mMapper.selectHorror();
		model.addAttribute("mlist", mlist);
		return "view/horror";
	}

	@GetMapping("/science")
	public String selectScience(Model model) {
		List<Movie> mlist = mMapper.selectScience();
		model.addAttribute("mlist", mlist);
		return "view/science";
	}

}
