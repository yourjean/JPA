package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring0303ApplicationTests {

    @Test
    void contextLoads() {
    }

}
