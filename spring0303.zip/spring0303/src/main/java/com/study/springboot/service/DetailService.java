package com.study.springboot.service;

import com.study.springboot.entity.Notice;

public interface DetailService {
    Notice detail(Long seq);

}
