package com.study.springboot.service;

import com.study.springboot.entity.Notice;

public interface NoticeService {
    Notice saveReply(Notice notice);

}
