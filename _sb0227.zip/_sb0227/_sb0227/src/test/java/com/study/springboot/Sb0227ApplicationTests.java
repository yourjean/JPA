package com.study.springboot;

import groovy.util.logging.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb0227ApplicationTests {

    @Test
    void contextLoads() {
        System.out.println("test");
    }

    @Test
    public void test2() {
        System.out.println("------------****");
    }

}
