package com.study.springboot.repository;

import com.study.springboot.entity.Person;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class PersonRepositoryTest {

    @Autowired

    PersonRepository personRepository;
    @Test //자료 입력하기
    @Disabled
    public void testIns(){
        IntStream.rangeClosed(1,10).forEach(t -> {
            Person person = Person.builder().name("이름"+t).addr("주소"+t).build();
            System.out.println(person);
            personRepository.save(person);
        });

    }

    @Test //자료 하나 가져오기
    @Transactional //전송하다 중간에 에러나면 처음상태로 돌아감-하나의 단위업무 정함
    @Disabled
    public void testSel(){
        Person person = personRepository.getOne(1L);
        System.out.println(person);
    }
    @Test //자료 가져오기2
    @Transactional //전송하다 중간에 에러나면 처음상태로 돌아감-하나의 단위업무 정함
    @Disabled
    public void testSel2(){
        Person person = personRepository.findById(1L).orElseThrow();
        System.out.println(person);
        List<Person> list = personRepository.findAll();
        list.stream().forEach(i ->{
            System.out.println(i);
        });
    }

    @Test //업데이트(insert와 비슷)
    @Disabled
    public void testUpd(){
        Person person = Person.builder().pid(1L).name("김갑돌").addr("마포구").build();
        personRepository.save(person);
    }

    @Test //삭제
    @Disabled
    public void testDel(){
        personRepository.deleteById(1L);
    }

    //JPQL select
    @Test
    @Disabled
    public void testSel3(){
        Person person = personRepository.findPersonByName("이름1");
        System.out.println(person);
    }

    //이름에 "1" 들어간것 선택
    @Test
    public void testSel4(){
        List<Person> list = personRepository.findPersonByNameLike("%1%");
        list.stream().forEach(t -> {
            System.out.println(t);
        });
    }

    //전체검색
    @Test
    @Disabled
    public void testSel5(){
        List<Person> list = personRepository.selectAll();
        list.stream().forEach(r ->{
            System.out.println(r);
        });
    }

    //"이름4" 인것 검색

    @Test
    @Disabled
    public void testSel6(){
        List<Person> list = personRepository.selectName("이름4");
        list.stream().forEach(r ->{
            System.out.println(r);
        });
    }

    //이름 like 검색
    @Test
    @Disabled
    public void testSel7(){
        List<Person> list = personRepository.selectName2("름");
        list.stream().forEach(r ->{
            System.out.println(r);
        });
    }

    //insert 여러개
    @Test
    public void insert1(){
        personRepository.insertPerson("연습","연습구");
    }

    //객체(VO같은)로 만들어서 삽입
    @Test
    public void insert2(){
        Person person = Person.builder().name("홍길순").addr("송파구").build();
        personRepository.insertPerson2(person);
    }
}