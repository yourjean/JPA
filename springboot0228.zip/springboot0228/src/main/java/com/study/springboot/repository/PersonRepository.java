package com.study.springboot.repository;

import com.study.springboot.entity.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface PersonRepository extends JpaRepository<Person,Long> {

    //JPQL

    Person findPersonByName(String name);

    List<Person> findPersonByNameLike(String name);

    //리스트로 가져오기
    @Query(value = "select * from person", nativeQuery = true)
    List<Person> selectAll();

    //이름으로 검색
    @Query(value = "select * from person where name = :name", nativeQuery = true)
    List<Person> selectName(@Param("name") String name);

    //이름 like 검색
    @Query(value = "select * from person where name like %:name%", nativeQuery = true)
    List<Person> selectName2(@Param("name") String name);

    //여러개의 파라미터로 검색
    @Transactional
    @Modifying
    @Query(value = "insert into person(name, addr) values(:name, :addr)", nativeQuery = true)
    void insertPerson(@Param("name") String name, @Param("addr") String addr);

    //객체타입(Person)으로 받아서 한번에 삽입
    @Transactional
    @Modifying
    @Query(value = "insert into person(name, addr) values(:#{#person.name}, :#{#person.addr})", nativeQuery = true)
    void insertPerson2(@Param("person") Person person);
}
